# 30分スタディ Ver.0.44.2 — 段階修正 2

## 今回の対象

- 中1英語読解3問の本文統一
- 学習画面に残っていた `Grade N:` 接頭辞の削除
- 今回の修正で目立った「正解だけ長い」選択肢の調整
- 同一刺激タイトルの本文・表・図不一致を検知する回帰チェック
- 正解選択肢の長さ偏り警告
- GitHub Actionsで回帰テストを実行

## 主な修正

### 中1英語
`v044_en_g1_read1` / `v044_en_g1_read2` / `v044_en_g1_write` の本文を次に統一。

Rina: Do you have any plans after school?
Leo: Yes. I need a book about animals for our science class.
Rina: I have one at home. I can bring it tomorrow.
Leo: Thanks, but I need it today. I can find one in the library.

`read1` の選択肢・解説を本文に合わせて修正し、`write` はRinaの立場で「明日持ってくる」と書かせる問題に変更。

### Grade接頭辞
対象5問の `Grade 1:` / `Grade 2:` / `Grade 3:` を削除。

### 選択肢長
- `v044_ja_lit_03a`
- `v044_sc_g1_control`
- `v044_en_g1_read1`
- `v044_ja_exp_03a`（軽微調整）

を調整。

## 自動検証

`scripts/check_question_quality_regressions.py` を追加。

- `Grade N:` の残存 → エラー
- 同じ教科・同じ `stimulusTitle` なのに passage/table/figure が不一致 → エラー
- 正解が「誤答最大長の1.3倍以上」かつ「6文字以上長い」 → 警告

GitHub Actionsでは以下を実行。

- `python scripts/validate_questions.py`
- `python scripts/audit_shizuoka.py`
- `python scripts/check_question_quality_regressions.py`
- `node scripts/test_reorder_grading.js`

## 検証結果

- 静岡地区品質ゲート: 0 errors
- 回帰チェック: 0 errors
- 並べ替え採点: 4/4 PASS
- JavaScript構文: OK
- 長さ偏り: 18 warnings（既存問題。今後の段階修正対象）
