#!/usr/bin/env python3
import json,re
from pathlib import Path
R=Path(__file__).resolve().parents[1]
qpath=R/'data/questions.json'
data=json.load(open(qpath,encoding='utf-8'))
qs=data['questions']
by={q['id']:q for q in qs}

def setq(id, **changes):
    q=by[id]
    for k,v in changes.items():
        q[k]=v

def delids(ids):
    global qs,by
    remove=set(ids)
    qs=[q for q in qs if q['id'] not in remove]
    data['questions']=qs
    by={q['id']:q for q in qs}

# A: ambiguous proverb distractor.
setq('v04_002',
    choices=[
        'つらくても、結果を急がず努力を続けること',
        '十分に準備してからでなければ物事を始めないこと',
        '難しいことは避け、得意なことを長く続けること',
        '成果が見えないときは早めに別の方法へ切り替えること'
    ],
    answer=0,
    explanation='「石の上にも三年」は、つらい状況でも辛抱強く続けることの大切さを表すことわざです。'
)

# Improve obviously weak cross-domain distractors.
setq('v04_021',
    choices=['ヨーロッパ','東南アジア','北アメリカ','南アメリカ'],
    answer=0,
    explanation='EU（欧州連合）はヨーロッパの国々を中心とする地域統合です。ほかの地域にも地域協力の枠組みがあります。'
)
setq('v04_024',
    choices=['山地・丘陵地','平野・低地','台地・段丘','盆地・谷底平野'],
    answer=0,
    explanation='日本の国土は山地・丘陵地の割合が大きく、平野や盆地は限られています。'
)
setq('v04_109',
    question='生物どうしの食べる・食べられる関係が、鎖のようにつながっている関係を何という？',
    choices=['食物連鎖','食物網','生態系','物質循環'],
    answer=0,
    explanation='食べる・食べられる関係が鎖状につながったものを食物連鎖といいます。複雑に網状につながると食物網と呼びます。'
)
setq('v04_084',
    question='母集団から一部を取り出して調べ、その結果から全体の傾向を推測する調査方法は？',
    choices=['標本調査','全数調査','無作為抽出','母集団'],
    answer=0,
    explanation='母集団の一部である標本を調べ、その結果から母集団全体の傾向を推測する方法を標本調査といいます。'
)

# English distractors: keep all options grammatical and in the same semantic field.
setq('v04_128',
    choices=[
        'Shall we have lunch together?',
        'Did you have lunch together?',
        'We have lunch together every day.',
        'You should have lunch before noon.'
    ],
    answer=0,
    explanation='Shall we ...? は「一緒に〜しませんか」と相手を誘ったり提案したりする表現です。'
)
setq('v04_016',
    choices=['because','although','if','when'],
    answer=0,
    explanation='because は理由を表し、「なぜなら〜だから」という内容を加えるときに使えます。'
)
setq('v04_111',
    choices=[
        'I am a junior high school student.',
        'I was a junior high school student.',
        'I am a junior high school teacher.',
        'I am a high school student.'
    ],
    answer=0,
    explanation='「私は中学生です。」では、主語 I に現在形の be 動詞 am を使い、a junior high school student と続けます。'
)
setq('v04_124',
    choices=[
        'This is the book that I bought yesterday.',
        'This is the book that I read yesterday.',
        'This is the book that she bought yesterday.',
        'This is the book that I bought last week.'
    ],
    answer=0,
    explanation='「私が昨日買った本」なので、the book の後に that I bought yesterday を続けます。'
)
setq('v04_122',
    question='現在完了の継続で、期間の前と起点の前に使う語の組合せとして正しいものは？（期間／起点）',
    choices=['for / since','since / for','during / since','for / ago'],
    answer=0,
    explanation='期間には for、継続が始まった起点には since を使います。'
)

# Japanese/social/science cue-word distractors rewritten as plausible misconceptions.
setq('v04_026',
    choices=[
        '広い耕地を確保しやすく、機械化に向いているから',
        '大都市に近く、狭い土地で集約的な農業が行いやすいから',
        '年間を通して温暖で、二期作に適しているから',
        '急な斜面が多く、段々畑を広げやすいから'
    ],
    answer=0,
    explanation='北海道では広い土地を確保しやすく、大型機械を使った大規模な畑作や酪農が発達しています。'
)
setq('v04_085',
    choices=['等しい','入射角の方が大きい','反射角の方が大きい','2つの角の和が90°になる'],
    answer=0,
    explanation='反射の法則により、法線を基準に測った入射角と反射角は等しくなります。'
)
setq('v044_ja_exp_01a',
    choices=[
        '利用状況を調べ、必要な場所に設備を整え、同じ条件で効果を確かめることが大切だ',
        '利用者数の違いを考えず、各場所に同じ数のベンチを置く方が公平で効果的だ',
        '休日午後の利用者数を調べれば、整備後に同じ条件で再調査する必要はない',
        '平日午前の利用者が少ない場所は、他の時間帯を調べず設備を減らしてよい'
    ]
)
setq('v044_ja_exp_03b',
    choices=[
        '個人で調べる時間と対面で意見を交換する時間を挙げ、目的に応じて方法を組み合わせる考えを示している',
        '資料を共有しやすい点を挙げ、タブレットを使う時間を増やすほど学習効果が高まると示している',
        '話し合いが減る可能性を挙げ、学校ではタブレットを使わない方がよいという考えを示している',
        '個人で調べる時間を挙げ、対面で意見を交換する時間の必要性は低いという考えを示している'
    ]
)
setq('v044_so_11',
    choices=[
        '国際の平和と安全の維持に主要な責任を負う',
        '国際的な保健活動を中心に調整する',
        '世界遺産の登録や文化財の保護を進める',
        '国際貿易のルールづくりと紛争解決を担う'
    ],
    answer=0,
    explanation='安全保障理事会は国際の平和と安全の維持に主要な責任を負います。ほかの選択肢は別の国際機関の役割に近い内容です。'
)

# English reading: remove cue words and Unit-name-as-content templates.
setq('v044_en_g2_read1',
    choices=[
        'The students used information from their activity to think about the next step.',
        'The students stopped before finishing because there was no litter.',
        'The students worked together without dividing into groups.',
        'The class cleaned the park but did not record the kinds of litter.'
    ]
)
setq('v044_en_g3_read1',
    choices=[
        'The student council wants to compare evidence before deciding.',
        'Most students supported the idea after the first trial event.',
        'The school decided to use reusable cups before collecting the trial data.',
        'The writer thinks reducing plastic waste is more important than comparing other effects.'
    ]
)
setq('v044_en_g3_read2',
    choices=[
        'A decision should consider different effects and evidence.',
        'Reducing plastic waste should be the main reason for choosing reusable cups.',
        'Trial events are unnecessary when students already support an idea.',
        'Using water to wash cups makes reusable cups a poor choice for school events.'
    ]
)

setq('v035_en_mitsumura_g1_00_1',
    passage="Aki: Hi, Sam. Are you ready for English class?\nSam: Almost. I have my notebook, but I don't have a pen.\nAki: You can use this one.\nSam: Thanks. After class, I play soccer with Ken. Do you want to join us?\nAki: Yes, I do.",
    stimulusTitle='中1英語 会話（オリジナル）',
    choices=[
        'Because Aki lends Sam a pen.',
        'Because Aki gives Sam a notebook.',
        'Because Aki helps Sam with soccer practice.',
        'Because Aki invites Sam to lunch.'
    ]
)
setq('v035_en_mitsumura_g2_00_2',
    passage="Mina planned to practice a presentation with her group on Friday. One member became sick that morning, so the group met online instead. They shared their ideas and practiced each part. They plan to meet at school again next Monday.",
    stimulusTitle='中2英語 読解（オリジナル）',
    choices=['One member was sick.','They needed a larger classroom.','They had finished practicing earlier in the week.','Mina wanted to work by herself.'],
    answer=0,
    explanation='The passage says one member became sick, so the group changed from an in-person practice to an online meeting.'
)
setq('v035_en_mitsumura_g2_01_2',
    passage="Mina's group planned to make a poster in the library after school. When they arrived, the library was being used for a meeting. They moved to an empty classroom and divided the work. Two students searched for information, and Mina organized the notes. They finished the first draft and agreed to meet again on Monday.",
    stimulusTitle='中2英語 読解（オリジナル・協働作業）',
    choices=[
        'They changed where they worked and continued the project.',
        'They waited for the library to open and did no work that day.',
        'They asked another group to finish the poster for them.',
        'They finished the poster before deciding what information to use.'
    ],
    answer=0,
    explanation='The library was unavailable, so the group moved to another room, divided the work, and continued the project.'
)

# Remove eight semantically duplicated older items, retaining the stronger counterparts.
delids(['ma005','ma004','ma003','ma006','sc001','sc004','sc005','so004'])

data['version']='0.44.5'
data['notes']=(data.get('notes','')+' Ver.0.44.5: resolved the remaining ambiguous item, replaced weak or ungrammatical distractors, removed eight semantic duplicates in the Shizuoka scope, removed Unit-name leakage from English passages, and expanded regression checks for cue words and duplicated content.').strip()

with open(qpath,'w',encoding='utf-8') as f:
    json.dump(data,f,ensure_ascii=False,indent=2)
    f.write('\n')
with open(R/'data/questions.js','w',encoding='utf-8') as f:
    f.write('window.QUESTION_DATA = '+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n')

# Version strings in app shell.
for rel in ['app.js','index.html','sw.js']:
    p=R/rel
    s=p.read_text(encoding='utf-8')
    s=s.replace('0.44.4','0.44.5')
    p.write_text(s,encoding='utf-8')

print('updated questions',len(data['questions']))
