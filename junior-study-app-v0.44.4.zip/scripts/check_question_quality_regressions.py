#!/usr/bin/env python3
import json,re,sys,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]
Q=json.load(open(R/'data/questions.json',encoding='utf-8'))['questions']
C=json.load(open(R/'data/curriculum.json',encoding='utf-8'))
UF={}
for s in C['subjects']:
  for f in s['fields']:
    for u in f['units']:
      UF[(s['id'],u['id'])]=f['id']
def field(q): return q.get('field') or UF.get((q.get('subject'),q.get('unit')))
def target(q):
  s=q.get('subject');p=q.get('textbookPublisher','common') or 'common'
  if s=='japanese': return p in ('common','sanseido')
  if s=='english': return p in ('common','mitsumura')
  if s=='math': return p in ('common','keirinkan')
  if s=='science': return p in ('common','keirinkan')
  if s=='social':
    if p=='common': return True
    f=field(q); return (f in ('geography','history') and p=='teikoku') or (f=='civics' and p=='tokyo-shoseki')
  return False
A=[q for q in Q if target(q)]
errors=[]; warnings=[]

# No development labels in student-facing prompts.
for q in A:
  if re.match(r'^Grade\s*\d+\s*:',q.get('question',''),re.I):
    errors.append(f"Grade prefix: {q['id']}")

# Same subject + stimulus title means the same stimulus payload.
groups=collections.defaultdict(list)
for q in A:
  title=q.get('stimulusTitle')
  if title and (q.get('passage') is not None or q.get('table') is not None or q.get('figure') is not None):
    groups[(q.get('subject'),title)].append(q)
for key,qs in groups.items():
  if len(qs)<2: continue
  def sig(q):
    return (q.get('passage'),json.dumps(q.get('table'),ensure_ascii=False,sort_keys=True),json.dumps(q.get('figure'),ensure_ascii=False,sort_keys=True))
  variants={sig(q) for q in qs}
  if len(variants)>1:
    errors.append(f"stimulus mismatch for {key}: {[q['id'] for q in qs]}")


# Elimination-cue words must not appear only in distractors.
# Text inside Japanese quotation marks is ignored because it may be a source quotation.
CUE_WORDS=('だけ','必ず','一切','まったく','絶対')
def strip_quoted(text):
  return re.sub(r'「[^」]*」','',str(text))
for q in A:
  if q.get('type') not in ('choice','multi'): continue
  choices=q.get('choices') or []
  if q.get('type')=='choice':
    a=q.get('answer'); correct={a} if isinstance(a,int) else set()
  else:
    aa=q.get('answers'); correct=set(aa) if isinstance(aa,list) else set()
  correct_text=' '.join(strip_quoted(choices[i]) for i in correct if isinstance(i,int) and 0<=i<len(choices))
  for cue in CUE_WORDS:
    bad=[i for i,c in enumerate(choices) if i not in correct and cue in strip_quoted(c)]
    if bad and cue not in correct_text:
      errors.append(f"distractor-only cue '{cue}': {q['id']} choices={bad}")

# Heuristic warning: correct choice is conspicuously longer than every distractor.
for q in A:
  if q.get('type')!='choice': continue
  ch=q.get('choices') or []; ans=q.get('answer')
  if not isinstance(ans,int) or not (0<=ans<len(ch)) or len(ch)<2: continue
  al=len(str(ch[ans]).strip())
  dl=[len(str(v).strip()) for i,v in enumerate(ch) if i!=ans]
  if not dl: continue
  mx=max(dl)
  if al>=mx*1.3 and al-mx>=6:
    warnings.append(f"long correct choice: {q['id']} correct={al} max_distractor={mx}")

print('regression errors=',len(errors))
for e in errors: print('ERROR',e)
print('length warnings=',len(warnings))
for w in warnings: print('WARNING',w)
sys.exit(1 if errors else 0)
